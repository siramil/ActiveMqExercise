package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.NotificationMessage;

@RestController
public class Controller {
    @Autowired
    JmsTemplate jmsTemplate;

    @GetMapping("/ping")
    private void send() {
        NotificationMessage notif = new NotificationMessage();
        notif.setMessage("ping");
        jmsTemplate.convertAndSend("ping-request", notif);
    }
}
