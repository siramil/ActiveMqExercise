package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;

import com.example.demo.model.NotificationMessage;

@Configuration
public class Receiver {
    @Autowired
    JmsTemplate jmsTemplate;
    
    @JmsListener(destination = "ping-request", containerFactory = "myFactory")
    public void receiveMessage(NotificationMessage notification) {
        System.out.println("Received <" + notification.getMessage() + ">");

    
    
    NotificationMessage notif = new NotificationMessage();
    notif.setMessage("pong");
    jmsTemplate.convertAndSend("pong-request", notif);
       
    }
    

   

}